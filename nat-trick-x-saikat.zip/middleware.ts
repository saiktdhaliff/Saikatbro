
/**
 * TECHNICAL DELIVERABLE: Next.js 14 Middleware
 * Note: Since this is a React SPA, this file is provided as requested 
 * but logic is implemented in AuthGuard.tsx for the live app.
 */

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const session = request.cookies.get('ntxs_session');
  const { pathname } = request.nextUrl;

  // Protect all routes except auth pages
  if (!session && pathname !== '/login' && pathname !== '/signup') {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  // Redirect logged in users away from auth pages
  if (session && (pathname === '/login' || pathname === '/signup')) {
    return NextResponse.redirect(new URL('/', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
