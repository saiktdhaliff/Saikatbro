
export interface User {
  id: string;
  name: string;
  email: string;
  bio: string;
  followerCount: number;
  followingCount: number;
  posts: string[]; // array of post IDs
  isMonetized: boolean;
  totalViews: number;
  totalDownloads: number;
  totalLikes: number;
}

export interface Post {
  id: string;
  uploaderId: string;
  uploaderName: string;
  fileName: string;
  fileSize: string;
  fileType: string;
  caption: string;
  likes: number;
  views: number;
  downloads: number;
  timestamp: number;
  likedBy: string[]; // user IDs
}

export enum FileCategory {
  DOCUMENT = 'DOCUMENT',
  ARCHIVE = 'ARCHIVE',
  CODE = 'CODE',
  OTHER = 'OTHER'
}
