
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { APP_NAME } from '../constants';
import { db } from '../services/db';
import { LayoutDashboard, User, Home, LogOut } from 'lucide-react';

const Navbar: React.FC = () => {
  const navigate = useNavigate();
  const currentUser = db.getAuthSession();

  const handleLogout = () => {
    db.setAuthSession(null);
    navigate('/login');
  };

  if (!currentUser) return null;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass h-16 border-b border-neutral-800 px-4 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
          <span className="text-black font-black text-xs">NTX</span>
        </div>
        <h1 className="text-white font-bold tracking-tighter text-lg uppercase hidden sm:block">
          {APP_NAME}
        </h1>
      </Link>

      <div className="flex items-center gap-1 md:gap-4">
        <Link to="/" className="p-2 hover:bg-neutral-800 rounded-lg transition-colors text-neutral-400 hover:text-white">
          <Home size={20} />
        </Link>
        <Link to="/dashboard" className="p-2 hover:bg-neutral-800 rounded-lg transition-colors text-neutral-400 hover:text-white">
          <LayoutDashboard size={20} />
        </Link>
        <Link to="/profile" className="p-2 hover:bg-neutral-800 rounded-lg transition-colors text-neutral-400 hover:text-white">
          <User size={20} />
        </Link>
        <button 
          onClick={handleLogout}
          className="p-2 hover:bg-red-900/20 hover:text-red-500 rounded-lg transition-colors text-neutral-400"
        >
          <LogOut size={20} />
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
