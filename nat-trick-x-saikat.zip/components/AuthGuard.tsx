
import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { db } from '../services/db';

interface AuthGuardProps {
  children: React.ReactNode;
}

/**
 * Technical Specification Enforcement:
 * Acts as Middleware to block all unauthorized access.
 * If not logged in, users are redirected to Login.
 */
const AuthGuard: React.FC<AuthGuardProps> = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const session = db.getAuthSession();

  useEffect(() => {
    const publicPaths = ['/login', '/signup'];
    if (!session && !publicPaths.includes(location.pathname)) {
      navigate('/login', { replace: true });
    } else if (session && publicPaths.includes(location.pathname)) {
      navigate('/', { replace: true });
    }
  }, [session, location.pathname, navigate]);

  if (!session && !['/login', '/signup'].includes(location.pathname)) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 bg-white rounded-lg"></div>
          <p className="text-neutral-500 font-black text-xs uppercase tracking-[0.3em]">Authenticating...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default AuthGuard;
