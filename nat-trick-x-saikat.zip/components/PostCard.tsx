
import React, { useState } from 'react';
import { Post, User } from '../types';
import { getFileIcon, APP_NAME } from '../constants';
import { db } from '../services/db';
import { Download, Heart, Eye, User as UserIcon } from 'lucide-react';

interface PostCardProps {
  post: Post;
  currentUser: User;
  onUpdate: () => void;
}

const PostCard: React.FC<PostCardProps> = ({ post, currentUser, onUpdate }) => {
  const [isLiked, setIsLiked] = useState(post.likedBy.includes(currentUser.id));

  const handleLike = () => {
    db.toggleLike(post.id, currentUser.id);
    setIsLiked(!isLiked);
    onUpdate();
  };

  const handleDownload = () => {
    db.incrementDownload(post.id);
    onUpdate();
    // Simulate file download
    const element = document.createElement('a');
    const file = new Blob(["Simulated Document Content"], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = post.fileName;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleFollow = () => {
    db.toggleFollow(currentUser.id, post.uploaderId);
    onUpdate();
  };

  return (
    <div className="glass rounded-xl overflow-hidden border border-neutral-800 hover:border-neutral-700 transition-all p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center text-neutral-400 border border-neutral-700">
            <UserIcon size={20} />
          </div>
          <div>
            <p className="font-semibold text-sm text-white">{post.uploaderName}</p>
            <p className="text-xs text-neutral-500">{new Date(post.timestamp).toLocaleDateString()}</p>
          </div>
        </div>
        {currentUser.id !== post.uploaderId && (
          <button 
            onClick={handleFollow}
            className="text-xs font-bold text-neutral-400 hover:text-white transition-colors"
          >
            Follow
          </button>
        )}
      </div>

      <div className="bg-neutral-900/50 rounded-lg p-4 flex items-center gap-4 mb-4 border border-neutral-800">
        <div className="p-3 bg-neutral-800 rounded-lg">
          {getFileIcon(post.fileName)}
        </div>
        <div className="overflow-hidden">
          <p className="font-bold text-neutral-200 truncate">{post.fileName}</p>
          <p className="text-xs text-neutral-500 uppercase">{post.fileType} • {post.fileSize}</p>
        </div>
      </div>

      {post.caption && (
        <p className="text-sm text-neutral-300 mb-4 px-1 italic">
          "{post.caption}"
        </p>
      )}

      <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
        <div className="flex items-center gap-4">
          <button 
            onClick={handleLike}
            className={`flex items-center gap-1.5 transition-colors ${isLiked ? 'text-red-500' : 'text-neutral-500 hover:text-neutral-300'}`}
          >
            <Heart size={18} fill={isLiked ? "currentColor" : "none"} />
            <span className="text-xs font-medium">{post.likes}</span>
          </button>
          <div className="flex items-center gap-1.5 text-neutral-500">
            <Eye size={18} />
            <span className="text-xs font-medium">{post.views}</span>
          </div>
        </div>

        <button 
          onClick={handleDownload}
          className="bg-white text-black text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-neutral-200 transition-colors"
        >
          <Download size={14} />
          Download
        </button>
      </div>
    </div>
  );
};

export default PostCard;
