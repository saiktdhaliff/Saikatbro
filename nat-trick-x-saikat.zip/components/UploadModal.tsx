
import React, { useState, useRef } from 'react';
import { db } from '../services/db';
import { Post, User } from '../types';
import { Plus, X, Upload, File as FileIcon, AlertCircle } from 'lucide-react';

interface UploadModalProps {
  currentUser: User;
  onClose: () => void;
  onSuccess: () => void;
}

const UploadModal: React.FC<UploadModalProps> = ({ currentUser, onClose, onSuccess }) => {
  const [caption, setCaption] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const mime = selectedFile.type;
      // Restriction: Absolutely NO images or videos
      if (mime.startsWith('image/') || mime.startsWith('video/')) {
        setError('Only documents are allowed (No images or videos)');
        setFile(null);
        return;
      }
      setError('');
      setFile(selectedFile);
    }
  };

  const handleUpload = () => {
    if (!file) {
      setError('Please select a document to share');
      return;
    }

    const newPost: Post = {
      id: Math.random().toString(36).substr(2, 9),
      uploaderId: currentUser.id,
      uploaderName: currentUser.name,
      fileName: file.name,
      fileSize: (file.size / 1024 / 1024).toFixed(2) + ' MB',
      fileType: file.name.split('.').pop()?.toUpperCase() || 'UNKNOWN',
      caption: caption.substring(0, 20),
      likes: 0,
      views: 0,
      downloads: 0,
      timestamp: Date.now(),
      likedBy: []
    };

    db.addPost(newPost);
    
    // Update user's post list
    const updatedUser = { ...currentUser };
    updatedUser.posts.push(newPost.id);
    db.saveUser(updatedUser);
    db.setAuthSession(updatedUser);

    onSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="glass w-full max-w-md rounded-2xl overflow-hidden border border-neutral-700 animate-in fade-in zoom-in duration-300">
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <h2 className="font-bold text-lg">Share Document</h2>
          <button onClick={onClose} className="p-1 hover:bg-neutral-800 rounded-full text-neutral-400">
            <X size={20} />
          </button>
        </div>

        <div className="p-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="w-full h-40 border-2 border-dashed border-neutral-700 rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-neutral-500 hover:bg-neutral-800/20 transition-all mb-4"
          >
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept=".pdf,.doc,.docx,.txt,.zep,.dark,.zip,.rar,.7z,.js,.ts"
            />
            {file ? (
              <div className="flex flex-col items-center">
                <FileIcon size={40} className="text-white mb-2" />
                <p className="text-sm font-bold text-white px-4 text-center truncate w-full">{file.name}</p>
                <p className="text-xs text-neutral-500">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
            ) : (
              <>
                <Upload size={40} className="text-neutral-600 mb-2" />
                <p className="text-sm font-medium text-neutral-400">Click to select file</p>
                <p className="text-[10px] text-neutral-600 uppercase">Documents • Archives • Code</p>
              </>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-xs font-bold text-neutral-500 uppercase mb-2">Caption (Max 20 characters)</label>
            <input 
              type="text"
              maxLength={20}
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Enter brief description..."
              className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-neutral-500"
            />
            <div className="flex justify-end mt-1">
              <span className={`text-[10px] ${caption.length >= 20 ? 'text-red-500' : 'text-neutral-600'}`}>
                {caption.length}/20
              </span>
            </div>
          </div>

          {error && (
            <div className="bg-red-900/20 border border-red-900/50 rounded-lg p-3 flex items-center gap-2 text-red-500 text-xs mb-4">
              <AlertCircle size={14} />
              {error}
            </div>
          )}

          <button 
            onClick={handleUpload}
            className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-neutral-200 transition-colors disabled:opacity-50"
            disabled={!file}
          >
            Post Document
          </button>
        </div>
      </div>
    </div>
  );
};

export default UploadModal;
