
import React from 'react';
import { FOOTER_TEXT } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="w-full py-6 mt-auto border-t border-neutral-800 bg-black flex justify-center items-center">
      <p className="text-neutral-500 text-sm font-medium tracking-widest uppercase">
        {FOOTER_TEXT}
      </p>
    </footer>
  );
};

export default Footer;
