import { User, Post } from '../types';

const USERS_KEY = 'ntxs_users';
const POSTS_KEY = 'ntxs_posts';
const AUTH_KEY = 'ntxs_auth_session';

export const db = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveUser: (user: User) => {
    const users = db.getUsers();
    const index = users.findIndex(u => u.id === user.id);
    if (index > -1) {
      users[index] = user;
    } else {
      users.push(user);
    }
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  getUserByEmail: (email: string): User | undefined => {
    return db.getUsers().find(u => u.email === email);
  },

  getUserById: (id: string): User | undefined => {
    return db.getUsers().find(u => u.id === id);
  },

  getPosts: (): Post[] => {
    const data = localStorage.getItem(POSTS_KEY);
    return data ? JSON.parse(data) : [];
  },

  addPost: (post: Post) => {
    const posts = db.getPosts();
    posts.unshift(post);
    localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
  },

  updatePost: (updatedPost: Post) => {
    const posts = db.getPosts();
    const index = posts.findIndex(p => p.id === updatedPost.id);
    if (index > -1) {
      posts[index] = updatedPost;
      localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
    }
  },

  incrementView: (postId: string) => {
    const posts = db.getPosts();
    const post = posts.find(p => p.id === postId);
    if (post) {
      post.views += 1;
      const uploader = db.getUserById(post.uploaderId);
      if (uploader) {
        uploader.totalViews += 1;
        db.saveUser(uploader);
      }
      db.updatePost(post);
    }
  },

  incrementDownload: (postId: string) => {
    const posts = db.getPosts();
    const post = posts.find(p => p.id === postId);
    if (post) {
      post.downloads += 1;
      const uploader = db.getUserById(post.uploaderId);
      if (uploader) {
        uploader.totalDownloads += 1;
        db.saveUser(uploader);
      }
      db.updatePost(post);
    }
  },

  toggleLike: (postId: string, userId: string) => {
    const posts = db.getPosts();
    const post = posts.find(p => p.id === postId);
    if (post) {
      const uploader = db.getUserById(post.uploaderId);
      if (post.likedBy.includes(userId)) {
        post.likedBy = post.likedBy.filter(id => id !== userId);
        post.likes -= 1;
        if (uploader) uploader.totalLikes -= 1;
      } else {
        post.likedBy.push(userId);
        post.likes += 1;
        if (uploader) uploader.totalLikes += 1;
      }
      if (uploader) db.saveUser(uploader);
      db.updatePost(post);
    }
  },

  toggleFollow: (currentUserId: string, targetUserId: string) => {
    const currentUser = db.getUserById(currentUserId);
    const targetUser = db.getUserById(targetUserId);
    if (currentUser && targetUser && currentUserId !== targetUserId) {
      targetUser.followerCount += 1;
      currentUser.followingCount += 1;
      db.saveUser(currentUser);
      db.saveUser(targetUser);
    }
  },

  setAuthSession: (user: User | null) => {
    if (user) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(user));
      // Technical deliverable: Sync cookie for Middleware enforcement
      document.cookie = `ntxs_session=true; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Strict`;
    } else {
      localStorage.removeItem(AUTH_KEY);
      // Clear cookie on logout
      document.cookie = "ntxs_session=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT";
    }
  },

  getAuthSession: (): User | null => {
    const data = localStorage.getItem(AUTH_KEY);
    return data ? JSON.parse(data) : null;
  }
};