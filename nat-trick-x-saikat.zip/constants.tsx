
import React from 'react';
import { 
  FileText, 
  FileArchive, 
  FileCode, 
  File as FileIcon, 
  Download, 
  Heart, 
  Eye, 
  TrendingUp, 
  User as UserIcon, 
  Plus, 
  Home, 
  BarChart3,
  LogOut,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

export const APP_NAME = "NAT TRICK X SAIKAT";
export const FOOTER_TEXT = "©saikatbro";
export const MONETIZATION_THRESHOLD = 500;

export const getFileIcon = (fileName: string) => {
  const ext = fileName.split('.').pop()?.toLowerCase();
  switch (ext) {
    case 'pdf':
    case 'doc':
    case 'docx':
    case 'txt':
    case 'rtf':
      return <FileText className="w-8 h-8 text-blue-400" />;
    case 'zip':
    case 'rar':
    case '7z':
    case 'tar':
    case 'zep':
    case 'dark':
      return <FileArchive className="w-8 h-8 text-yellow-400" />;
    case 'js':
    case 'ts':
    case 'tsx':
    case 'html':
    case 'css':
    case 'py':
    case 'json':
      return <FileCode className="w-8 h-8 text-green-400" />;
    default:
      return <FileIcon className="w-8 h-8 text-neutral-400" />;
  }
};
