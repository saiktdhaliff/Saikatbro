
import React, { useState } from 'react';
import { db } from '../services/db';
import { User } from '../types';
import { User as UserIcon, Edit3, Save, X, Settings } from 'lucide-react';

const Profile: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User>(db.getAuthSession() as User);
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser.name);
  const [bio, setBio] = useState(currentUser.bio);

  const handleSave = () => {
    const updatedUser = { ...currentUser, name, bio };
    db.saveUser(updatedUser);
    db.setAuthSession(updatedUser);
    setCurrentUser(updatedUser);
    setIsEditing(false);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 pt-24 pb-20">
      <div className="glass rounded-3xl border border-neutral-800 overflow-hidden mb-8">
        <div className="h-32 premium-gradient border-b border-neutral-800"></div>
        <div className="px-8 pb-8">
          <div className="flex justify-between items-end -mt-12 mb-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-2xl bg-neutral-900 border-4 border-black flex items-center justify-center shadow-2xl">
                <UserIcon size={40} className="text-neutral-500" />
              </div>
            </div>
            <button 
              onClick={() => isEditing ? handleSave() : setIsEditing(true)}
              className="bg-white text-black font-bold px-6 py-2.5 rounded-xl hover:bg-neutral-200 transition-colors flex items-center gap-2"
            >
              {isEditing ? <><Save size={18} /> Save</> : <><Edit3 size={18} /> Edit Profile</>}
            </button>
          </div>

          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-neutral-500 uppercase mb-1 tracking-widest">Full Identity Name</label>
                <input 
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-neutral-500"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-neutral-500 uppercase mb-1 tracking-widest">Digital Biography</label>
                <textarea 
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-neutral-500 h-24 resize-none"
                />
              </div>
              <button 
                onClick={() => setIsEditing(false)}
                className="text-neutral-500 text-xs font-bold uppercase tracking-widest hover:text-white"
              >
                Cancel Changes
              </button>
            </div>
          ) : (
            <div>
              <h2 className="text-3xl font-black text-white tracking-tighter mb-1 uppercase italic">{currentUser.name}</h2>
              <p className="text-neutral-500 font-medium mb-6">{currentUser.email}</p>
              <div className="glass bg-neutral-900/40 p-6 rounded-2xl border border-neutral-800 mb-8">
                <p className="text-neutral-300 text-sm leading-relaxed">{currentUser.bio}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="glass bg-neutral-900/20 p-6 rounded-2xl border border-neutral-800 text-center">
                  <p className="text-2xl font-black text-white">{currentUser.followerCount}</p>
                  <p className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mt-1">Followers</p>
                </div>
                <div className="glass bg-neutral-900/20 p-6 rounded-2xl border border-neutral-800 text-center">
                  <p className="text-2xl font-black text-white">{currentUser.followingCount}</p>
                  <p className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mt-1">Following</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 text-neutral-500 mb-4 px-2">
        <Settings size={16} />
        <span className="text-[10px] font-black uppercase tracking-widest">Account Integrity Secured</span>
      </div>
    </div>
  );
};

export default Profile;
