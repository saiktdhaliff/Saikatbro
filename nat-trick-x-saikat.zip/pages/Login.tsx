
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { APP_NAME } from '../constants';
import { db } from '../services/db';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = db.getUserByEmail(email);
    
    if (user && password) { // Simple mock check
      db.setAuthSession(user);
      navigate('/');
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-black">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex w-16 h-16 bg-white rounded-2xl items-center justify-center mb-6 shadow-2xl shadow-white/10">
            <span className="text-black font-black text-2xl">NX</span>
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter uppercase mb-2">
            {APP_NAME}
          </h1>
          <p className="text-neutral-500 font-medium">Secure Private Document Network</p>
        </div>

        <form onSubmit={handleLogin} className="glass p-8 rounded-3xl border border-neutral-800">
          <h2 className="text-xl font-bold mb-6 text-center">Login to Account</h2>
          
          <div className="space-y-4 mb-8">
            <div>
              <label className="block text-xs font-bold text-neutral-500 uppercase mb-2">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-neutral-500 transition-all"
                placeholder="name@example.com"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-neutral-500 uppercase mb-2">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-neutral-500 transition-all"
                placeholder="••••••••"
              />
            </div>
          </div>

          {error && <p className="text-red-500 text-xs mb-4 text-center">{error}</p>}

          <button 
            type="submit" 
            className="w-full bg-white text-black font-black py-4 rounded-xl hover:bg-neutral-200 transition-all transform active:scale-95 shadow-lg shadow-white/10 mb-6"
          >
            AUTHENTICATE
          </button>

          <p className="text-center text-sm text-neutral-500">
            Don't have an account? <Link to="/signup" className="text-white font-bold hover:underline">Sign up</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;
