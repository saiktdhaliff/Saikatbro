
import React from 'react';
import { db } from '../services/db';
import { User } from '../types';
import { MONETIZATION_THRESHOLD } from '../constants';
import { BarChart3, TrendingUp, Download, Eye, Heart, ShieldCheck, Lock } from 'lucide-react';

const Dashboard: React.FC = () => {
  const currentUser = db.getAuthSession() as User;
  
  const stats = [
    { label: 'Network Reach (Views)', value: currentUser.totalViews, icon: <Eye className="text-blue-400" /> },
    { label: 'Data Extractions (Downloads)', value: currentUser.totalDownloads, icon: <Download className="text-green-400" /> },
    { label: 'Endorsements (Likes)', value: currentUser.totalLikes, icon: <Heart className="text-red-400" /> },
    { label: 'Published Assets', value: currentUser.posts.length, icon: <BarChart3 className="text-purple-400" /> }
  ];

  const canApplyForMonetization = currentUser.followerCount >= MONETIZATION_THRESHOLD;

  return (
    <div className="max-w-4xl mx-auto px-4 pt-24 pb-20">
      <div className="mb-10 text-center">
        <h2 className="text-3xl font-black tracking-tighter text-white uppercase italic mb-2">Command Center</h2>
        <p className="text-xs text-neutral-500 font-bold uppercase tracking-[0.2em]">Real-time Network Analytics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        {stats.map((stat, i) => (
          <div key={i} className="glass p-6 rounded-2xl border border-neutral-800 hover:border-neutral-700 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-neutral-900 rounded-lg">{stat.icon}</div>
              <TrendingUp size={16} className="text-neutral-700" />
            </div>
            <p className="text-3xl font-black text-white mb-1">{stat.value.toLocaleString()}</p>
            <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="glass rounded-3xl border border-neutral-800 overflow-hidden mb-10">
        <div className="premium-gradient p-8 text-white relative overflow-hidden">
          <div className="relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full mb-4">
              <ShieldCheck size={14} className="text-green-400" />
              <span className="text-[10px] font-black uppercase tracking-widest">Monetization Hub</span>
            </div>
            <h3 className="text-2xl font-black uppercase italic mb-2">Revenue Generation Program</h3>
            <p className="text-neutral-400 text-sm max-w-lg">
              Unlock the ability to monetize your document assets once you reach the established network threshold of {MONETIZATION_THRESHOLD} followers.
            </p>
          </div>
          <div className="absolute right-[-20px] top-[-20px] opacity-10">
            <TrendingUp size={240} />
          </div>
        </div>

        <div className="p-8 border-t border-neutral-800">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="w-full md:w-1/2">
              <div className="flex justify-between items-end mb-2">
                <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest">Network Growth Status</span>
                <span className="text-sm font-bold text-white">{currentUser.followerCount} / {MONETIZATION_THRESHOLD}</span>
              </div>
              <div className="h-3 w-full bg-neutral-900 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="h-full bg-white transition-all duration-1000" 
                  style={{ width: `${Math.min((currentUser.followerCount / MONETIZATION_THRESHOLD) * 100, 100)}%` }}
                />
              </div>
            </div>

            <button 
              disabled={!canApplyForMonetization}
              className={`flex items-center justify-center gap-2 px-8 py-4 rounded-xl font-black uppercase tracking-widest transition-all ${
                canApplyForMonetization 
                ? 'bg-white text-black hover:scale-105 active:scale-95 cursor-pointer shadow-xl shadow-white/5' 
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
              }`}
            >
              {canApplyForMonetization ? <><TrendingUp size={18} /> Apply for Monetization</> : <><Lock size={18} /> Insufficient Followers</>}
            </button>
          </div>

          {!canApplyForMonetization && (
            <p className="mt-6 text-[10px] text-neutral-600 font-bold uppercase tracking-widest text-center">
              Target: Reach {MONETIZATION_THRESHOLD - currentUser.followerCount} more followers to unlock financial scaling
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
